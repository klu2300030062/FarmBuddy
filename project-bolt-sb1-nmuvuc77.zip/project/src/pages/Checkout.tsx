import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  CreditCard, 
  ChevronRight,
  Truck, 
  ShoppingBag,
  CheckCircle,
  X,
  Lock,
  Clock
} from 'lucide-react';

// Mock cart data
const mockCartItems = [
  { id: 1, name: 'Organic Tomatoes', price: 2.99, quantity: 2, image: 'https://images.pexels.com/photos/1440119/pexels-photo-1440119.jpeg', farmer: 'Green Valley Farm' },
  { id: 2, name: 'Fresh Strawberries', price: 4.49, quantity: 1, image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg', farmer: 'Berry Hill Farm' },
  { id: 3, name: 'Brown Rice', price: 3.99, quantity: 1, image: 'https://images.pexels.com/photos/7543105/pexels-photo-7543105.jpeg', farmer: 'Golden Fields' },
];

const Checkout: React.FC = () => {
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');
  const [deliveryOption, setDeliveryOption] = useState<'standard' | 'express'>('standard');
  
  // Calculate totals
  const subtotal = mockCartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  const deliveryFee = deliveryOption === 'standard' ? 5.99 : 9.99;
  const tax = subtotal * 0.08; // Assuming 8% tax
  const total = subtotal + deliveryFee + tax;
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(step + 1);
  };
  
  const renderStepIndicator = () => {
    return (
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            step >= 1 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            1
          </div>
          <div className={`w-16 h-1 ${step >= 2 ? 'bg-primary-600' : 'bg-gray-200'}`}></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            step >= 2 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            2
          </div>
          <div className={`w-16 h-1 ${step >= 3 ? 'bg-primary-600' : 'bg-gray-200'}`}></div>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            step >= 3 ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            3
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container-custom">
        <h1 className="text-2xl font-bold mb-4 text-center">Checkout</h1>
        
        {renderStepIndicator()}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-lg shadow-sm overflow-hidden mb-6"
              >
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-xl font-bold mb-4">Shipping Information</h2>
                  <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 mb-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                        <input type="text" className="input" required />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                        <input type="text" className="input" required />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                        <input type="email" className="input" required />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                        <input type="tel" className="input" required />
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                      <input type="text" className="input mb-2" placeholder="Street Address" required />
                      <input type="text" className="input" placeholder="Apt, Suite, Unit, etc. (optional)" />
                    </div>
                    
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-3 mb-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                        <input type="text" className="input" required />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">State/Province</label>
                        <input type="text" className="input" required />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">ZIP/Postal Code</label>
                        <input type="text" className="input" required />
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                      <select className="input" required>
                        <option value="US">United States</option>
                        <option value="CA">Canada</option>
                        <option value="UK">United Kingdom</option>
                        <option value="AU">Australia</option>
                      </select>
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="font-medium mb-3">Delivery Options</h3>
                      <div className="space-y-3">
                        <label className={`flex items-center p-4 border rounded-md cursor-pointer transition-colors ${
                          deliveryOption === 'standard' ? 'border-primary-500 bg-primary-50' : 'border-gray-200'
                        }`}>
                          <input 
                            type="radio" 
                            name="deliveryOption" 
                            className="h-4 w-4 text-primary-600"
                            checked={deliveryOption === 'standard'}
                            onChange={() => setDeliveryOption('standard')}
                          />
                          <div className="ml-3 flex-1">
                            <div className="flex justify-between">
                              <span className="font-medium">Standard Delivery</span>
                              <span className="font-medium">$5.99</span>
                            </div>
                            <p className="text-sm text-gray-500">Delivery within 3-5 business days</p>
                          </div>
                        </label>
                        
                        <label className={`flex items-center p-4 border rounded-md cursor-pointer transition-colors ${
                          deliveryOption === 'express' ? 'border-primary-500 bg-primary-50' : 'border-gray-200'
                        }`}>
                          <input 
                            type="radio" 
                            name="deliveryOption" 
                            className="h-4 w-4 text-primary-600"
                            checked={deliveryOption === 'express'}
                            onChange={() => setDeliveryOption('express')}
                          />
                          <div className="ml-3 flex-1">
                            <div className="flex justify-between">
                              <span className="font-medium">Express Delivery</span>
                              <span className="font-medium">$9.99</span>
                            </div>
                            <p className="text-sm text-gray-500">Delivery within 1-2 business days</p>
                          </div>
                        </label>
                      </div>
                    </div>
                    
                    <div className="flex justify-between">
                      <Link to="/customer/cart" className="btn-outline flex items-center">
                        <ChevronRight className="h-4 w-4 mr-1 rotate-180" />
                        Back to Cart
                      </Link>
                      <button type="submit" className="btn-primary">
                        Continue to Payment
                      </button>
                    </div>
                  </form>
                </div>
              </motion.div>
            )}
            
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-lg shadow-sm overflow-hidden mb-6"
              >
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-xl font-bold mb-4">Payment Method</h2>
                  
                  <div className="mb-6">
                    <div className="flex space-x-3 mb-4">
                      <button 
                        className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
                          paymentMethod === 'card' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                        onClick={() => setPaymentMethod('card')}
                      >
                        Credit Card
                      </button>
                      <button 
                        className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
                          paymentMethod === 'paypal' ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                        onClick={() => setPaymentMethod('paypal')}
                      >
                        PayPal
                      </button>
                    </div>
                    
                    {paymentMethod === 'card' ? (
                      <form onSubmit={handleSubmit}>
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Card Number</label>
                          <div className="relative">
                            <input 
                              type="text" 
                              className="input pr-10" 
                              placeholder="1234 5678 9012 3456" 
                              required 
                            />
                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                              <CreditCard className="h-5 w-5 text-gray-400" />
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">Expiration Date</label>
                            <input type="text" className="input" placeholder="MM/YY" required />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">CVC</label>
                            <input type="text" className="input" placeholder="123" required />
                          </div>
                        </div>
                        
                        <div className="mb-6">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Name on Card</label>
                          <input type="text" className="input" placeholder="John Doe" required />
                        </div>
                        
                        <div className="flex items-center mb-6">
                          <Lock className="h-5 w-5 text-gray-500 mr-2" />
                          <span className="text-sm text-gray-500">Your payment information is secure and encrypted</span>
                        </div>
                        
                        <div className="flex justify-between">
                          <button 
                            type="button" 
                            className="btn-outline flex items-center"
                            onClick={() => setStep(1)}
                          >
                            <ChevronRight className="h-4 w-4 mr-1 rotate-180" />
                            Back
                          </button>
                          <button type="submit" className="btn-primary">
                            Complete Order
                          </button>
                        </div>
                      </form>
                    ) : (
                      <div>
                        <p className="mb-4 text-gray-700">You will be redirected to PayPal to complete your payment.</p>
                        
                        <div className="flex justify-between">
                          <button 
                            className="btn-outline flex items-center"
                            onClick={() => setStep(1)}
                          >
                            <ChevronRight className="h-4 w-4 mr-1 rotate-180" />
                            Back
                          </button>
                          <button 
                            className="btn-primary"
                            onClick={(e) => handleSubmit(e as React.FormEvent)}
                          >
                            Continue with PayPal
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
            
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-lg shadow-sm overflow-hidden mb-6"
              >
                <div className="p-6 text-center">
                  <div className="mb-6">
                    <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                  </div>
                  
                  <h2 className="text-2xl font-bold mb-4">Order Confirmed!</h2>
                  <p className="text-gray-600 mb-6">
                    Thank you for your order. We've received your payment and will begin processing your items shortly.
                  </p>
                  
                  <div className="bg-gray-50 rounded-md p-4 mb-6 inline-block">
                    <p className="text-gray-700 font-medium">Order Number</p>
                    <p className="text-2xl font-bold">#AG-{Math.floor(10000 + Math.random() * 90000)}</p>
                  </div>
                  
                  <div className="flex justify-center flex-wrap gap-4">
                    <Link to="/customer/dashboard" className="btn-primary">
                      Back to Dashboard
                    </Link>
                    <Link to="/customer/orders" className="btn-outline flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      Track Order
                    </Link>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-4">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-bold mb-4">Order Summary</h2>
                
                <div className="space-y-4 mb-6">
                  {mockCartItems.map(item => (
                    <div key={item.id} className="flex">
                      <div className="h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="ml-4 flex-1">
                        <h4 className="font-medium text-sm">{item.name}</h4>
                        <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-xs text-gray-500">{item.farmer}</span>
                          <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-gray-200 pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    <span>${deliveryFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold pt-2 border-t border-gray-200 text-lg">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-primary-100 text-primary-600 mr-3">
                    <ShoppingBag className="h-5 w-5" />
                  </div>
                  <span className="text-sm text-gray-600">
                    {mockCartItems.reduce((sum, item) => sum + item.quantity, 0)} items in your cart
                  </span>
                </div>
                
                <div className="mt-4 flex items-center">
                  <div className="p-2 rounded-full bg-blue-100 text-blue-600 mr-3">
                    <Truck className="h-5 w-5" />
                  </div>
                  <span className="text-sm text-gray-600">
                    Estimated delivery: {deliveryOption === 'standard' ? '3-5 business days' : '1-2 business days'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;