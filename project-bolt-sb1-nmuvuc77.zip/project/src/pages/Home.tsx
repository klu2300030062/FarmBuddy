import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronRight, Leaf, ShoppingBasket, TrendingUp, Users } from 'lucide-react';

// Sample categories data
const categories = [
  { id: 1, name: 'Vegetables', icon: '🥕', description: 'Fresh farm vegetables', image: 'https://images.pexels.com/photos/3370704/pexels-photo-3370704.jpeg' },
  { id: 2, name: 'Fruits', icon: '🍎', description: 'Seasonal fruits', image: 'https://images.pexels.com/photos/1458694/pexels-photo-1458694.jpeg' },
  { id: 3, name: 'Grains', icon: '🌾', description: 'Organic grains', image: 'https://images.pexels.com/photos/326082/pexels-photo-326082.jpeg' },
  { id: 4, name: 'Dairy', icon: '🥛', description: 'Farm fresh dairy', image: 'https://images.pexels.com/photos/248337/pexels-photo-248337.jpeg' },
  { id: 5, name: 'Poultry', icon: '🥚', description: 'Free range poultry products', image: 'https://images.pexels.com/photos/583840/pexels-photo-583840.jpeg' },
  { id: 6, name: 'Herbs', icon: '🌿', description: 'Fresh culinary herbs', image: 'https://images.pexels.com/photos/906150/pexels-photo-906150.jpeg' },
];

// Featured products data
const featuredProducts = [
  { id: 1, name: 'Organic Tomatoes', price: 2.99, farmer: 'Green Valley Farm', image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg' },
  { id: 2, name: 'Fresh Strawberries', price: 4.49, farmer: 'Berry Hill Farm', image: 'https://images.pexels.com/photos/70746/strawberries-red-fruit-royalty-free-70746.jpeg' },
  { id: 3, name: 'Brown Rice', price: 3.99, farmer: 'Golden Fields', image: 'https://images.pexels.com/photos/4110251/pexels-photo-4110251.jpeg' },
  { id: 4, name: 'Organic Eggs', price: 5.29, farmer: 'Happy Hens Farm', image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg' },
];

const Home: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-900 to-primary-700 text-white">
        <div className="container-custom py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
                Fresh from Farm to Your Table
              </h1>
              <p className="text-lg md:text-xl mb-8 text-gray-100">
                Connect directly with local farmers for the freshest produce at fair prices.
                Support sustainable agriculture and enjoy the best quality food.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register" className="btn bg-white text-primary-700 hover:bg-gray-100 focus:ring-white">
                  Get Started
                </Link>
                <Link to="/about" className="btn bg-transparent border border-white text-white hover:bg-white/10 focus:ring-white">
                  Learn More
                </Link>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="hidden md:block"
            >
              <img 
                src="https://images.pexels.com/photos/2255459/pexels-photo-2255459.jpeg" 
                alt="Farmer with produce" 
                className="rounded-lg shadow-xl"
              />
            </motion.div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How FarmBuddy Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our platform connects farmers directly with customers, eliminating middlemen
              and ensuring fair prices for everyone.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* For Farmers */}
            <motion.div 
              className="p-6 bg-gray-50 rounded-lg shadow-sm"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="bg-primary-100 p-3 rounded-full w-fit mb-4">
                <Leaf className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">For Farmers</h3>
              <p className="text-gray-600 mb-4">
                List your products, set your prices, and connect directly with customers.
                No more middlemen cutting into your profits.
              </p>
              <Link to="/register" className="text-primary-600 hover:text-primary-700 font-medium inline-flex items-center">
                Register as Farmer <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </motion.div>
            
            {/* For Customers */}
            <motion.div 
              className="p-6 bg-gray-50 rounded-lg shadow-sm"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="bg-secondary-100 p-3 rounded-full w-fit mb-4">
                <ShoppingBasket className="h-8 w-8 text-secondary-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">For Customers</h3>
              <p className="text-gray-600 mb-4">
                Browse farm-fresh products, place orders with local farmers, and enjoy
                high-quality produce delivered to your doorstep.
              </p>
              <Link to="/register" className="text-secondary-600 hover:text-secondary-700 font-medium inline-flex items-center">
                Register as Customer <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </motion.div>
            
            {/* Benefits */}
            <motion.div 
              className="p-6 bg-gray-50 rounded-lg shadow-sm"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="bg-accent-100 p-3 rounded-full w-fit mb-4">
                <TrendingUp className="h-8 w-8 text-accent-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">Benefits</h3>
              <p className="text-gray-600 mb-4">
                Support local agriculture, reduce food miles, and enjoy fresh products
                at fair prices. Win-win for everyone!
              </p>
              <Link to="/about" className="text-accent-600 hover:text-accent-700 font-medium inline-flex items-center">
                Learn More <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Product Categories</h2>
              <p className="text-gray-600">Explore our diverse range of farm products</p>
            </div>
            <Link to="/products" className="text-primary-600 font-medium hover:text-primary-700 hidden md:flex items-center">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <motion.div
                key={category.id}
                className="card group"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={category.image} 
                    alt={category.name} 
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-5">
                  <div className="flex items-center mb-2">
                    <span className="text-2xl mr-2">{category.icon}</span>
                    <h3 className="text-xl font-bold">{category.name}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{category.description}</p>
                  <Link 
                    to={`/products?category=${category.id}`} 
                    className="text-primary-600 hover:text-primary-700 font-medium inline-flex items-center"
                  >
                    Browse Products <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Link to="/products" className="btn-primary">
              View All Categories
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Products</h2>
              <p className="text-gray-600">Handpicked quality products from local farmers</p>
            </div>
            <Link to="/products" className="text-primary-600 font-medium hover:text-primary-700 hidden md:flex items-center">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <motion.div
                key={product.id}
                className="card group"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                  <p className="text-gray-500 text-sm mb-2">by {product.farmer}</p>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-lg">${product.price.toFixed(2)}</span>
                    <Link 
                      to={`/products/${product.id}`}
                      className="btn-primary text-sm py-1.5"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Link to="/products" className="btn-primary">
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hear from farmers and customers who have transformed their agricultural
              experience through our platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Farmer Testimonial */}
            <motion.div 
              className="bg-white p-6 rounded-lg shadow-md"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-4">
                <div className="bg-primary-100 p-1 rounded-full mr-4">
                  <img 
                    src="https://images.pexels.com/photos/1482101/pexels-photo-1482101.jpeg" 
                    alt="Farmer John" 
                    className="w-16 h-16 rounded-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-lg">John Thompson</h3>
                  <p className="text-gray-600">Organic Vegetable Farmer</p>
                </div>
              </div>
              <p className="text-gray-700">
                "Since joining FarmBuddy, I've been able to reach more customers and get fair prices for my produce. 
                The platform has eliminated middlemen, letting me interact directly with buyers. My profits have increased by 30%!"
              </p>
            </motion.div>
            
            {/* Customer Testimonial */}
            <motion.div 
              className="bg-white p-6 rounded-lg shadow-md"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-4">
                <div className="bg-secondary-100 p-1 rounded-full mr-4">
                  <img 
                    src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg" 
                    alt="Customer Sarah" 
                    className="w-16 h-16 rounded-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Sarah Johnson</h3>
                  <p className="text-gray-600">Home Chef & Customer</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The quality of produce I get through FarmBuddy is incomparable. I love knowing exactly where my food 
                comes from and supporting local farmers directly. The freshness makes a huge difference in my cooking!"
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-accent-700 to-accent-600 text-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Agricultural Experience?</h2>
              <p className="text-lg mb-8">
                Join thousands of farmers and customers already benefiting from direct farm-to-table connections.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register" className="btn bg-white text-accent-700 hover:bg-gray-100 focus:ring-white">
                  Create an Account
                </Link>
                <Link to="/contact" className="btn bg-transparent border border-white text-white hover:bg-white/10 focus:ring-white">
                  Contact Us
                </Link>
              </div>
            </div>
            <div className="flex items-center justify-center">
              <div className="bg-white/10 p-8 rounded-lg backdrop-blur-sm">
                <div className="flex items-center justify-center mb-6">
                  <Users className="h-16 w-16 text-white" />
                </div>
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Join Our Community</h3>
                  <p className="text-lg mb-2">
                    <span className="text-4xl font-bold">5000+</span>
                  </p>
                  <p>Farmers and customers connected</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;