import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, 
  Heart, 
  Truck, 
  Award, 
  Clock, 
  ChevronRight,
  Star,
  Leaf,
  User,
  MessageCircle
} from 'lucide-react';

// Mock product data
const mockProduct = {
  id: 1,
  name: 'Organic Tomatoes',
  description: 'Fresh, organically grown tomatoes from our sustainable farm. These vibrant red tomatoes are perfect for salads, sandwiches, or cooking. Grown without pesticides or chemical fertilizers.',
  price: 2.99,
  farmer: {
    id: 101,
    name: 'Green Valley Farm',
    location: 'Sunnyvale, CA',
    rating: 4.8,
    reviews: 156,
    joined: 'Member since 2020'
  },
  category: 'Vegetables',
  tags: ['organic', 'fresh', 'local', 'sustainable'],
  stock: 50,
  unit: 'lb',
  rating: 4.8,
  reviews: 32,
  images: [
    'https://images.pexels.com/photos/1440119/pexels-photo-1440119.jpeg',
    'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg',
    'https://images.pexels.com/photos/1327838/pexels-photo-1327838.jpeg',
    'https://images.pexels.com/photos/1435904/pexels-photo-1435904.jpeg'
  ],
  nutritionFacts: {
    calories: 22,
    fat: '0.2g',
    carbs: '4.8g',
    protein: '1.1g',
    vitamins: ['Vitamin C', 'Vitamin K', 'Potassium', 'Folate']
  },
  relatedProducts: [
    { id: 2, name: 'Organic Cucumber', price: 1.49, image: 'https://images.pexels.com/photos/2329440/pexels-photo-2329440.jpeg' },
    { id: 3, name: 'Bell Peppers', price: 2.29, image: 'https://images.pexels.com/photos/128536/pexels-photo-128536.jpeg' },
    { id: 4, name: 'Fresh Spinach', price: 1.99, image: 'https://images.pexels.com/photos/2325839/pexels-photo-2325839.jpeg' }
  ]
};

// Mock reviews
const mockReviews = [
  {
    id: 1,
    user: 'Sarah M.',
    date: '2023-04-28',
    rating: 5,
    comment: 'These tomatoes are absolutely delicious! So much flavor compared to store-bought ones. Will definitely order again.'
  },
  {
    id: 2,
    user: 'Mike T.',
    date: '2023-04-15',
    rating: 4,
    comment: 'Very fresh and tasty. Shipped well and arrived in perfect condition.'
  },
  {
    id: 3,
    user: 'Jessica K.',
    date: '2023-04-10',
    rating: 5,
    comment: 'Amazing quality and taste! These tomatoes make the best salads and sauces.'
  }
];

const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [mainImage, setMainImage] = useState(mockProduct.images[0]);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');
  
  const handleIncrement = () => {
    if (quantity < mockProduct.stock) {
      setQuantity(quantity + 1);
    }
  };
  
  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="container-custom">
        {/* Breadcrumb Navigation */}
        <nav className="flex mb-6 text-sm">
          <Link to="/" className="text-gray-500 hover:text-primary-600">Home</Link>
          <ChevronRight className="h-4 w-4 mx-2 text-gray-400 flex-shrink-0 self-center" />
          <Link to="/products" className="text-gray-500 hover:text-primary-600">Products</Link>
          <ChevronRight className="h-4 w-4 mx-2 text-gray-400 flex-shrink-0 self-center" />
          <Link to={`/products?category=${mockProduct.category}`} className="text-gray-500 hover:text-primary-600">{mockProduct.category}</Link>
          <ChevronRight className="h-4 w-4 mx-2 text-gray-400 flex-shrink-0 self-center" />
          <span className="text-gray-900">{mockProduct.name}</span>
        </nav>
        
        {/* Product Main Content */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
            {/* Product Images */}
            <div className="lg:col-span-1">
              <div className="mb-4 rounded-lg overflow-hidden">
                <img 
                  src={mainImage} 
                  alt={mockProduct.name} 
                  className="w-full h-[300px] object-cover"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {mockProduct.images.map((image, index) => (
                  <div 
                    key={index}
                    className={`cursor-pointer rounded-md overflow-hidden border-2 ${
                      mainImage === image ? 'border-primary-500' : 'border-transparent'
                    }`}
                    onClick={() => setMainImage(image)}
                  >
                    <img 
                      src={image} 
                      alt={`${mockProduct.name} ${index + 1}`} 
                      className="w-full h-16 object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
            
            {/* Product Info */}
            <div className="lg:col-span-2">
              <div className="flex justify-between items-start">
                <div>
                  <h1 className="text-2xl font-bold mb-2">{mockProduct.name}</h1>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-sm text-gray-600">{mockProduct.rating} ({mockProduct.reviews} reviews)</span>
                    </div>
                    <span className="mx-2 text-gray-300">|</span>
                    <Link to={`/farmers/${mockProduct.farmer.id}`} className="text-sm text-primary-600 hover:text-primary-700">
                      by {mockProduct.farmer.name}
                    </Link>
                  </div>
                </div>
                <button className="p-2 rounded-full text-gray-400 hover:text-red-500 hover:bg-gray-100">
                  <Heart className="h-6 w-6" />
                </button>
              </div>
              
              <div className="flex items-baseline mb-6">
                <span className="text-3xl font-bold text-gray-900">${mockProduct.price.toFixed(2)}</span>
                <span className="ml-2 text-sm text-gray-500">per {mockProduct.unit}</span>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <Leaf className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm">Organically grown without pesticides</span>
                </div>
                <div className="flex items-center mb-4">
                  <Truck className="h-5 w-5 text-blue-500 mr-2" />
                  <span className="text-sm">Free delivery on orders over $35</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-yellow-500 mr-2" />
                  <span className="text-sm">Order by 4pm for next-day delivery</span>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="font-medium mb-2">Quantity</h3>
                <div className="flex">
                  <button 
                    className="p-2 border border-gray-300 rounded-l-md"
                    onClick={handleDecrement}
                    disabled={quantity <= 1}
                  >
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M3 8H13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </button>
                  <input 
                    type="number" 
                    className="w-20 text-center border-t border-b border-gray-300"
                    value={quantity}
                    onChange={e => setQuantity(parseInt(e.target.value) || 1)}
                    min="1"
                    max={mockProduct.stock}
                  />
                  <button 
                    className="p-2 border border-gray-300 rounded-r-md"
                    onClick={handleIncrement}
                    disabled={quantity >= mockProduct.stock}
                  >
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M3 8H13M8 3V13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </button>
                  <span className="ml-4 text-sm text-gray-500 self-center">
                    {mockProduct.stock} available
                  </span>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="btn-primary flex-1 flex items-center justify-center">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Add to Cart
                </button>
                <Link to="/checkout" className="btn-secondary flex-1 text-center">
                  Buy Now
                </Link>
              </div>
              
              <div className="mt-8 border-t border-gray-200 pt-6">
                <h3 className="font-medium mb-4">About the Farmer</h3>
                <Link to={`/farmers/${mockProduct.farmer.id}`} className="flex items-center hover:bg-gray-50 p-3 rounded-md transition-colors">
                  <div className="bg-primary-100 p-2 rounded-full mr-4">
                    <User className="h-8 w-8 text-primary-600" />
                  </div>
                  <div>
                    <p className="font-medium">{mockProduct.farmer.name}</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Star className="h-3 w-3 text-yellow-400 fill-current mr-1" />
                      <span>{mockProduct.farmer.rating} ({mockProduct.farmer.reviews} reviews)</span>
                      <span className="mx-1">•</span>
                      <span>{mockProduct.farmer.location}</span>
                    </div>
                    <p className="text-xs text-gray-500">{mockProduct.farmer.joined}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-400 ml-auto" />
                </Link>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Tabs */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8">
          <div className="border-b border-gray-200">
            <div className="flex overflow-x-auto">
              <button
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === 'description' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
                }`}
                onClick={() => setActiveTab('description')}
              >
                Description
              </button>
              <button
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === 'nutrition' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
                }`}
                onClick={() => setActiveTab('nutrition')}
              >
                Nutrition Facts
              </button>
              <button
                className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === 'reviews' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
                }`}
                onClick={() => setActiveTab('reviews')}
              >
                Reviews ({mockReviews.length})
              </button>
            </div>
          </div>
          
          <div className="p-6">
            {activeTab === 'description' && (
              <div>
                <p className="text-gray-700 mb-6">
                  {mockProduct.description}
                </p>
                
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Product Details</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>100% certified organic</li>
                    <li>Harvested at peak ripeness</li>
                    <li>No pesticides or chemical fertilizers</li>
                    <li>Sustainably grown using regenerative farming practices</li>
                    <li>Rich in essential vitamins and antioxidants</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Product Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {mockProduct.tags.map((tag, index) => (
                      <Link 
                        key={index} 
                        to={`/products?tag=${tag}`}
                        className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700 hover:bg-gray-200"
                      >
                        {tag}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'nutrition' && (
              <div>
                <div className="mb-6">
                  <h3 className="font-medium mb-4">Nutrition Information</h3>
                  <p className="text-sm text-gray-500 mb-4">Per 100g serving</p>
                  
                  <div className="border border-gray-200 rounded-md">
                    <div className="grid grid-cols-2 border-b border-gray-200">
                      <div className="p-3 font-medium">Calories</div>
                      <div className="p-3">{mockProduct.nutritionFacts.calories}</div>
                    </div>
                    <div className="grid grid-cols-2 border-b border-gray-200">
                      <div className="p-3 font-medium">Total Fat</div>
                      <div className="p-3">{mockProduct.nutritionFacts.fat}</div>
                    </div>
                    <div className="grid grid-cols-2 border-b border-gray-200">
                      <div className="p-3 font-medium">Total Carbohydrates</div>
                      <div className="p-3">{mockProduct.nutritionFacts.carbs}</div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="p-3 font-medium">Protein</div>
                      <div className="p-3">{mockProduct.nutritionFacts.protein}</div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-4">Vitamins and Minerals</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {mockProduct.nutritionFacts.vitamins.map((vitamin, index) => (
                      <div key={index} className="bg-green-50 p-4 rounded-md text-center">
                        <div className="text-green-600 font-medium">{vitamin}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'reviews' && (
              <div>
                <div className="flex items-center mb-6">
                  <div className="flex-shrink-0 mr-4">
                    <div className="text-5xl font-bold text-gray-900">{mockProduct.rating}</div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-5 w-5 ${i < Math.floor(mockProduct.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                    <div className="text-sm text-gray-500 mt-1">{mockProduct.reviews} reviews</div>
                  </div>
                  
                  <div className="flex-1">
                    {[5, 4, 3, 2, 1].map(rating => {
                      const count = mockReviews.filter(r => r.rating === rating).length;
                      const percentage = (count / mockReviews.length) * 100;
                      
                      return (
                        <div key={rating} className="flex items-center mb-1">
                          <div className="text-sm text-gray-600 w-8">{rating} ★</div>
                          <div className="flex-1 h-2 bg-gray-200 rounded-full mx-2">
                            <div 
                              className="h-2 bg-yellow-400 rounded-full" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <div className="text-sm text-gray-600 w-8">{count}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <div className="mb-6">
                  <button className="btn-primary">Write a Review</button>
                </div>
                
                <div className="space-y-6">
                  {mockReviews.map(review => (
                    <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                      <div className="flex justify-between mb-2">
                        <div className="font-medium">{review.user}</div>
                        <div className="text-sm text-gray-500">{review.date}</div>
                      </div>
                      <div className="flex mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Related Products */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {mockProduct.relatedProducts.map(product => (
              <motion.div
                key={product.id}
                className="card group"
                whileHover={{ y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">${product.price.toFixed(2)}</span>
                    <Link 
                      to={`/products/${product.id}`}
                      className="btn-primary text-sm py-1.5"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;