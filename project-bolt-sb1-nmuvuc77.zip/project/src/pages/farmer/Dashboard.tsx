import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  BarChart, 
  ShoppingBag, 
  Package, 
  Clock, 
  Truck, 
  Plus, 
  Edit, 
  Trash,
  ChevronRight, 
  DollarSign,
  Calendar
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

// Mock data for the farmer dashboard
const mockProducts = [
  { id: 1, name: 'Organic Tomatoes', price: 2.99, stock: 50, status: 'active', image: 'https://images.pexels.com/photos/1440119/pexels-photo-1440119.jpeg' },
  { id: 2, name: 'Fresh Carrots', price: 1.49, stock: 30, status: 'active', image: 'https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg' },
  { id: 3, name: 'Strawberries', price: 3.99, stock: 10, status: 'low', image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg' },
  { id: 4, name: 'Organic Eggs', price: 4.49, stock: 24, status: 'active', image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg' },
];

const mockOrders = [
  { id: 101, customer: 'Sarah Johnson', date: '2023-05-15', items: 3, total: 23.97, status: 'delivered' },
  { id: 102, customer: 'Mike Thompson', date: '2023-05-16', items: 2, total: 8.48, status: 'processing' },
  { id: 103, customer: 'Emily Davis', date: '2023-05-17', items: 5, total: 35.45, status: 'shipped' },
  { id: 104, customer: 'Robert Wilson', date: '2023-05-18', items: 1, total: 4.49, status: 'pending' },
];

// Stats data
const statsData = [
  { title: 'Total Sales', value: '$1,254.89', icon: DollarSign, color: 'text-green-500 bg-green-100' },
  { title: 'Products', value: '24', icon: Package, color: 'text-blue-500 bg-blue-100' },
  { title: 'Pending Orders', value: '8', icon: Clock, color: 'text-yellow-500 bg-yellow-100' },
  { title: 'Total Customers', value: '42', icon: ShoppingBag, color: 'text-purple-500 bg-purple-100' },
];

const FarmerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="container-custom">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Farmer Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user?.name}! Here's an overview of your farm business.</p>
        </div>

        {/* Dashboard Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6 overflow-hidden">
          <div className="flex overflow-x-auto">
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'overview' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'products' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('products')}
            >
              My Products
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'orders' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('orders')}
            >
              Orders
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'analytics' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('analytics')}
            >
              Analytics
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'settings' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('settings')}
            >
              Settings
            </button>
          </div>
        </div>

        {/* Active Tab Content */}
        <div className="animate-fade-in">
          {activeTab === 'overview' && (
            <Overview />
          )}
          
          {activeTab === 'products' && (
            <Products products={mockProducts} />
          )}
          
          {activeTab === 'orders' && (
            <Orders orders={mockOrders} />
          )}
          
          {activeTab === 'analytics' && (
            <Analytics />
          )}
          
          {activeTab === 'settings' && (
            <Settings />
          )}
        </div>
      </div>
    </div>
  );
};

// Overview Tab
const Overview: React.FC = () => {
  return (
    <div>
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsData.map((stat, index) => (
          <motion.div
            key={index}
            className="bg-white p-6 rounded-lg shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <div className="flex items-center">
              <div className={`p-3 rounded-full mr-4 ${stat.color}`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-gray-500">{stat.title}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Recent Activity and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold">Recent Orders</h2>
            <Link to="/farmer/orders" className="text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center">
              View All <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {mockOrders.slice(0, 3).map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">#{order.id}</td>
                    <td className="px-4 py-3 text-sm text-gray-500">{order.customer}</td>
                    <td className="px-4 py-3 text-sm text-gray-500">{order.date}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">${order.total.toFixed(2)}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${
                        order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                        order.status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                        order.status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-bold mb-6">Quick Actions</h2>
          
          <div className="space-y-4">
            <Link to="/farmer/products/add" className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">
              <div className="p-2 rounded-full bg-primary-100 text-primary-600 mr-4">
                <Plus className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium">Add New Product</p>
                <p className="text-sm text-gray-500">List new items for sale</p>
              </div>
            </Link>
            
            <Link to="/farmer/orders/pending" className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">
              <div className="p-2 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium">Pending Orders</p>
                <p className="text-sm text-gray-500">Review and process orders</p>
              </div>
            </Link>
            
            <Link to="/farmer/shipments" className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">
              <div className="p-2 rounded-full bg-blue-100 text-blue-600 mr-4">
                <Truck className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium">Manage Shipments</p>
                <p className="text-sm text-gray-500">Track deliveries and updates</p>
              </div>
            </Link>
            
            <Link to="/farmer/analytics" className="flex items-center p-4 border border-gray-200 rounded-md hover:bg-gray-50 transition-colors">
              <div className="p-2 rounded-full bg-purple-100 text-purple-600 mr-4">
                <BarChart className="h-5 w-5" />
              </div>
              <div>
                <p className="font-medium">View Analytics</p>
                <p className="text-sm text-gray-500">Check sales performance</p>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Monthly Calendar / Upcoming Events */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-bold">Upcoming Deliveries</h2>
          <div className="flex items-center">
            <Calendar className="h-5 w-5 text-gray-500 mr-2" />
            <span className="text-sm font-medium">May 2023</span>
          </div>
        </div>
        
        <div className="space-y-4">
          {[1, 2, 3].map((_, index) => (
            <div key={index} className="flex items-center p-4 border border-gray-200 rounded-md">
              <div className="bg-primary-100 text-primary-800 font-bold rounded-md p-3 mr-4 text-center min-w-16">
                <div className="text-xs text-primary-600">May</div>
                <div className="text-xl">{20 + index}</div>
              </div>
              <div className="flex-1">
                <p className="font-medium">Delivery to {['Farmstead Market', 'Green Grocer', 'Community Co-op'][index]}</p>
                <p className="text-sm text-gray-500">
                  {['10 boxes of mixed vegetables', '5 crates of fresh strawberries', '15 dozen eggs'][index]}
                </p>
              </div>
              <div>
                <span className="inline-flex px-2 py-1 text-xs rounded-full font-medium bg-yellow-100 text-yellow-800">
                  Scheduled
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Products Tab
interface ProductsProps {
  products: Array<{
    id: number;
    name: string;
    price: number;
    stock: number;
    status: string;
    image: string;
  }>;
}

const Products: React.FC<ProductsProps> = ({ products }) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">My Products</h2>
        <Link to="/farmer/products/add" className="btn-primary flex items-center">
          <Plus className="h-4 w-4 mr-1" /> Add Product
        </Link>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {products.map((product) => (
                <tr key={product.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-md overflow-hidden mr-3">
                        <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{product.name}</p>
                        <p className="text-sm text-gray-500">ID: #{product.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${product.price.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{product.stock} units</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${
                      product.status === 'active' ? 'bg-green-100 text-green-800' :
                      product.status === 'low' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {product.status === 'active' ? 'Active' : 
                       product.status === 'low' ? 'Low Stock' : 'Out of Stock'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex space-x-2">
                      <button className="p-1 text-blue-600 hover:text-blue-800">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="p-1 text-red-600 hover:text-red-800">
                        <Trash className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Orders Tab
interface OrdersProps {
  orders: Array<{
    id: number;
    customer: string;
    date: string;
    items: number;
    total: number;
    status: string;
  }>;
}

const Orders: React.FC<OrdersProps> = ({ orders }) => {
  const [filter, setFilter] = useState('all');
  
  const filteredOrders = filter === 'all' 
    ? orders 
    : orders.filter(order => order.status === filter);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Orders</h2>
        
        <div className="flex space-x-2">
          <select 
            className="input max-w-xs"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Orders</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
          </select>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Items</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#{order.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.customer}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.items}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${order.total.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                      order.status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <Link to={`/farmer/orders/${order.id}`} className="text-primary-600 hover:text-primary-800 font-medium">
                      View Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Analytics Tab
const Analytics: React.FC = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Sales Analytics</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Monthly Sales</h3>
          <div className="h-64 flex items-center justify-center bg-gray-100 rounded-md">
            <BarChart className="h-12 w-12 text-gray-400" />
            <p className="ml-3 text-gray-500">Sales chart will display here</p>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Top Selling Products</h3>
          <div className="space-y-4">
            {['Organic Tomatoes', 'Fresh Strawberries', 'Organic Eggs', 'Fresh Carrots'].map((product, index) => (
              <div key={index} className="flex items-center">
                <div className="w-full bg-gray-200 rounded-full h-4 mr-2">
                  <div 
                    className="bg-primary-600 h-4 rounded-full" 
                    style={{ width: `${90 - (index * 15)}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 whitespace-nowrap">{product}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
        <h3 className="text-lg font-semibold mb-4">Sales by Category</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {['Vegetables', 'Fruits', 'Dairy'].map((category, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-md">
              <h4 className="font-medium mb-2">{category}</h4>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold">${(400 - (index * 75)).toFixed(2)}</span>
                <span className={`text-sm ${index === 0 ? 'text-green-600' : 'text-gray-600'}`}>
                  {index === 0 ? '+12%' : index === 1 ? '+5%' : '-2%'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Customer Demographics</h3>
        <div className="h-64 flex items-center justify-center bg-gray-100 rounded-md">
          <p className="text-gray-500">Customer demographics chart will display here</p>
        </div>
      </div>
    </div>
  );
};

// Settings Tab
const Settings: React.FC = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Account Settings</h2>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Profile Information</h3>
          
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input type="text" className="input" defaultValue="John Doe" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input type="email" className="input" defaultValue="john@example.com" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
              <input type="tel" className="input" defaultValue="+1 (555) 123-4567" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Farm Name</label>
              <input type="text" className="input" defaultValue="Green Valley Farm" />
            </div>
          </div>
          
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Farm Address</label>
            <textarea className="input min-h-24" defaultValue="123 Farm Road, Countryside, State, 12345"></textarea>
          </div>
          
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
            <textarea 
              className="input min-h-24" 
              defaultValue="We are a family-owned organic farm specializing in heirloom vegetables and free-range eggs. Our farming practices focus on sustainability and biodiversity."
            ></textarea>
          </div>
          
          <div className="mt-6">
            <button className="btn-primary">Save Changes</button>
          </div>
        </div>
        
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Payment Information</h3>
          
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
              <input type="text" className="input" defaultValue="First National Bank" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
              <input type="text" className="input" defaultValue="XXXX-XXXX-XXXX-1234" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Routing Number</label>
              <input type="text" className="input" defaultValue="XXX-XXX-XXX" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tax ID / SSN</label>
              <input type="text" className="input" defaultValue="XXX-XX-XXXX" />
            </div>
          </div>
          
          <div className="mt-6">
            <button className="btn-primary">Update Payment Info</button>
          </div>
        </div>
        
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">Security</h3>
          
          <div className="space-y-6">
            <div>
              <h4 className="font-medium mb-2">Change Password</h4>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                  <input type="password" className="input" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                  <input type="password" className="input" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                  <input type="password" className="input" />
                </div>
              </div>
              
              <div className="mt-4">
                <button className="btn-primary">Update Password</button>
              </div>
            </div>
            
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
              <p className="text-sm text-gray-600 mb-4">Enhance your account security by enabling two-factor authentication.</p>
              <button className="btn-outline">Enable 2FA</button>
            </div>
            
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-medium text-red-600 mb-2">Delete Account</h4>
              <p className="text-sm text-gray-600 mb-4">Once you delete your account, there is no going back. Please be certain.</p>
              <button className="btn bg-red-600 text-white hover:bg-red-700 focus:ring-red-500">Delete Account</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FarmerDashboard;