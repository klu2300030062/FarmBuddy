import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import FarmerDashboard from './pages/farmer/Dashboard';
import CustomerDashboard from './pages/customer/Dashboard';
import ProductDetails from './pages/ProductDetails';
import Checkout from './pages/Checkout';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="products/:id" element={<ProductDetails />} />
          
          {/* Farmer Routes */}
          <Route path="farmer" element={<ProtectedRoute userType="farmer" />}>
            <Route path="dashboard" element={<FarmerDashboard />} />
          </Route>
          
          {/* Customer Routes */}
          <Route path="customer" element={<ProtectedRoute userType="customer" />}>
            <Route path="dashboard" element={<CustomerDashboard />} />
            <Route path="checkout" element={<Checkout />} />
          </Route>
        </Route>
      </Routes>
    </AuthProvider>
  );
}

export default App;