import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

// Initialize environment variables
dotenv.config();

// Mock database
let users = [
  {
    id: '1',
    name: 'John Farmer',
    email: 'farmer@example.com',
    password: '$2a$10$1JsG2n2u4G1SIL1JyS6ZD.i5BqAzK4yNkCPtoW/BHdXL8B32V5Mry', // "password123"
    userType: 'farmer'
  },
  {
    id: '2',
    name: 'Alice Customer',
    email: 'customer@example.com',
    password: '$2a$10$1JsG2n2u4G1SIL1JyS6ZD.i5BqAzK4yNkCPtoW/BHdXL8B32V5Mry', // "password123"
    userType: 'customer'
  }
];

let products = [
  {
    id: '1',
    name: 'Organic Tomatoes',
    description: 'Fresh, organically grown tomatoes from our sustainable farm.',
    price: 2.99,
    stock: 50,
    categoryId: '1',
    farmerId: '1',
    image: 'https://images.pexels.com/photos/1440119/pexels-photo-1440119.jpeg'
  },
  {
    id: '2',
    name: 'Fresh Strawberries',
    description: 'Sweet and juicy strawberries picked at peak ripeness.',
    price: 4.49,
    stock: 30,
    categoryId: '2',
    farmerId: '1',
    image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg'
  },
  {
    id: '3',
    name: 'Brown Rice',
    description: 'Organic, whole grain brown rice.',
    price: 3.99,
    stock: 100,
    categoryId: '3',
    farmerId: '1',
    image: 'https://images.pexels.com/photos/7543105/pexels-photo-7543105.jpeg'
  }
];

let categories = [
  { id: '1', name: 'Vegetables', icon: '🥕' },
  { id: '2', name: 'Fruits', icon: '🍎' },
  { id: '3', name: 'Grains', icon: '🌾' },
  { id: '4', name: 'Dairy', icon: '🥛' },
  { id: '5', name: 'Poultry', icon: '🥚' },
  { id: '6', name: 'Herbs', icon: '🌿' }
];

let orders = [];

// Create Express app
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// JWT authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }
  
  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET || 'defaultsecret');
    req.user = verified;
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid token.' });
  }
};

// Routes

// Auth routes
app.post('/api/login', async (req, res) => {
  const { email, password, userType } = req.body;
  
  // Find user
  const user = users.find(u => u.email === email && u.userType === userType);
  if (!user) {
    return res.status(400).json({ message: 'Invalid email or password.' });
  }
  
  // Check password
  const validPassword = await bcrypt.compare(password, user.password);
  if (!validPassword) {
    return res.status(400).json({ message: 'Invalid email or password.' });
  }
  
  // Create and assign token
  const token = jwt.sign(
    { id: user.id, userType: user.userType },
    process.env.JWT_SECRET || 'defaultsecret',
    { expiresIn: '1h' }
  );
  
  // Send response without password
  const { password: _, ...userWithoutPassword } = user;
  res.status(200).json({
    user: userWithoutPassword,
    token
  });
});

app.post('/api/register', async (req, res) => {
  const { name, email, password, userType } = req.body;
  
  // Check if user already exists
  if (users.some(u => u.email === email)) {
    return res.status(400).json({ message: 'User already exists.' });
  }
  
  // Hash the password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);
  
  // Create new user
  const newUser = {
    id: (users.length + 1).toString(),
    name,
    email,
    password: hashedPassword,
    userType
  };
  
  users.push(newUser);
  
  // Create and assign token
  const token = jwt.sign(
    { id: newUser.id, userType: newUser.userType },
    process.env.JWT_SECRET || 'defaultsecret',
    { expiresIn: '1h' }
  );
  
  // Send response without password
  const { password: _, ...userWithoutPassword } = newUser;
  res.status(201).json({
    user: userWithoutPassword,
    token
  });
});

// Product routes
app.get('/api/products', (req, res) => {
  const { categoryId, farmerId, search } = req.query;
  
  let filteredProducts = [...products];
  
  if (categoryId) {
    filteredProducts = filteredProducts.filter(p => p.categoryId === categoryId);
  }
  
  if (farmerId) {
    filteredProducts = filteredProducts.filter(p => p.farmerId === farmerId);
  }
  
  if (search) {
    const searchLower = search.toLowerCase();
    filteredProducts = filteredProducts.filter(p => 
      p.name.toLowerCase().includes(searchLower) || 
      p.description.toLowerCase().includes(searchLower)
    );
  }
  
  res.status(200).json(filteredProducts);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  
  if (!product) {
    return res.status(404).json({ message: 'Product not found.' });
  }
  
  res.status(200).json(product);
});

app.post('/api/products', authenticateToken, (req, res) => {
  const { name, description, price, stock, categoryId, image } = req.body;
  
  // Check if user is a farmer
  if (req.user.userType !== 'farmer') {
    return res.status(403).json({ message: 'Only farmers can add products.' });
  }
  
  const newProduct = {
    id: (products.length + 1).toString(),
    name,
    description,
    price,
    stock,
    categoryId,
    farmerId: req.user.id,
    image
  };
  
  products.push(newProduct);
  res.status(201).json(newProduct);
});

app.put('/api/products/:id', authenticateToken, (req, res) => {
  const { name, description, price, stock, categoryId, image } = req.body;
  
  // Find product
  const productIndex = products.findIndex(p => p.id === req.params.id);
  
  if (productIndex === -1) {
    return res.status(404).json({ message: 'Product not found.' });
  }
  
  // Check if user is the owner of the product
  if (products[productIndex].farmerId !== req.user.id) {
    return res.status(403).json({ message: 'Access denied. You can only update your own products.' });
  }
  
  // Update product
  products[productIndex] = {
    ...products[productIndex],
    name: name || products[productIndex].name,
    description: description || products[productIndex].description,
    price: price || products[productIndex].price,
    stock: stock || products[productIndex].stock,
    categoryId: categoryId || products[productIndex].categoryId,
    image: image || products[productIndex].image
  };
  
  res.status(200).json(products[productIndex]);
});

app.delete('/api/products/:id', authenticateToken, (req, res) => {
  // Find product
  const productIndex = products.findIndex(p => p.id === req.params.id);
  
  if (productIndex === -1) {
    return res.status(404).json({ message: 'Product not found.' });
  }
  
  // Check if user is the owner of the product
  if (products[productIndex].farmerId !== req.user.id) {
    return res.status(403).json({ message: 'Access denied. You can only delete your own products.' });
  }
  
  // Delete product
  const deletedProduct = products.splice(productIndex, 1)[0];
  res.status(200).json(deletedProduct);
});

// Category routes
app.get('/api/categories', (req, res) => {
  res.status(200).json(categories);
});

// Order routes
app.post('/api/orders', authenticateToken, (req, res) => {
  const { items, shippingAddress, paymentMethod, total } = req.body;
  
  // Check if user is a customer
  if (req.user.userType !== 'customer') {
    return res.status(403).json({ message: 'Only customers can place orders.' });
  }
  
  // Create new order
  const newOrder = {
    id: (orders.length + 1).toString(),
    customerId: req.user.id,
    items,
    shippingAddress,
    paymentMethod,
    total,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  
  orders.push(newOrder);
  res.status(201).json(newOrder);
});

app.get('/api/orders', authenticateToken, (req, res) => {
  let userOrders;
  
  if (req.user.userType === 'customer') {
    // Customers can only see their own orders
    userOrders = orders.filter(o => o.customerId === req.user.id);
  } else if (req.user.userType === 'farmer') {
    // Farmers can see orders that contain their products
    userOrders = orders.filter(o => 
      o.items.some(item => {
        const product = products.find(p => p.id === item.productId);
        return product && product.farmerId === req.user.id;
      })
    );
  } else {
    return res.status(403).json({ message: 'Unauthorized access.' });
  }
  
  res.status(200).json(userOrders);
});

app.get('/api/orders/:id', authenticateToken, (req, res) => {
  const order = orders.find(o => o.id === req.params.id);
  
  if (!order) {
    return res.status(404).json({ message: 'Order not found.' });
  }
  
  // Check if user has access to this order
  if (
    req.user.userType === 'customer' && order.customerId !== req.user.id ||
    req.user.userType === 'farmer' && !order.items.some(item => {
      const product = products.find(p => p.id === item.productId);
      return product && product.farmerId === req.user.id;
    })
  ) {
    return res.status(403).json({ message: 'Access denied.' });
  }
  
  res.status(200).json(order);
});

app.put('/api/orders/:id/status', authenticateToken, (req, res) => {
  const { status } = req.body;
  
  // Find order
  const orderIndex = orders.findIndex(o => o.id === req.params.id);
  
  if (orderIndex === -1) {
    return res.status(404).json({ message: 'Order not found.' });
  }
  
  // Check if user is a farmer and has products in this order
  if (req.user.userType === 'farmer') {
    const hasFarmerProducts = orders[orderIndex].items.some(item => {
      const product = products.find(p => p.id === item.productId);
      return product && product.farmerId === req.user.id;
    });
    
    if (!hasFarmerProducts) {
      return res.status(403).json({ message: 'Access denied. You can only update orders containing your products.' });
    }
  } else {
    return res.status(403).json({ message: 'Only farmers can update order status.' });
  }
  
  // Update order status
  orders[orderIndex].status = status;
  res.status(200).json(orders[orderIndex]);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;