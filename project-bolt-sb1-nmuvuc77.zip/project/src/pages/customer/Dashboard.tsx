import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Grid, 
  ShoppingBag, 
  Heart, 
  Clock, 
  Star, 
  Search,
  ChevronRight, 
  ShoppingCart,
  Filter
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

// Mock data for the customer dashboard
const mockProducts = [
  { id: 1, name: 'Organic Tomatoes', price: 2.99, farmer: 'Green Valley Farm', rating: 4.8, image: 'https://images.pexels.com/photos/1440119/pexels-photo-1440119.jpeg' },
  { id: 2, name: 'Fresh Strawberries', price: 4.49, farmer: 'Berry Hill Farm', rating: 4.9, image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg' },
  { id: 3, name: 'Brown Rice', price: 3.99, farmer: 'Golden Fields', rating: 4.5, image: 'https://images.pexels.com/photos/7543105/pexels-photo-7543105.jpeg' },
  { id: 4, name: 'Organic Eggs', price: 5.29, farmer: 'Happy Hens Farm', rating: 4.7, image: 'https://images.pexels.com/photos/162712/egg-white-food-protein-162712.jpeg' },
  { id: 5, name: 'Fresh Carrots', price: 1.49, farmer: 'Green Valley Farm', rating: 4.6, image: 'https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg' },
  { id: 6, name: 'Organic Honey', price: 7.99, farmer: 'Busy Bee Apiary', rating: 4.9, image: 'https://images.pexels.com/photos/1556706/pexels-photo-1556706.jpeg' },
  { id: 7, name: 'Spinach Bunch', price: 2.49, farmer: 'Green Valley Farm', rating: 4.5, image: 'https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg' },
  { id: 8, name: 'Fresh Apples', price: 3.29, farmer: 'Apple Orchard', rating: 4.7, image: 'https://images.pexels.com/photos/1510392/pexels-photo-1510392.jpeg' },
];

const mockOrders = [
  { id: 101, date: '2023-05-15', items: 3, total: 23.97, status: 'delivered' },
  { id: 102, date: '2023-05-10', items: 2, total: 8.48, status: 'delivered' },
  { id: 103, date: '2023-05-05', items: 5, total: 35.45, status: 'delivered' },
  { id: 104, date: '2023-04-29', items: 1, total: 4.49, status: 'delivered' },
];

// Categories
const categories = [
  { name: 'Vegetables', icon: '🥕', count: 28 },
  { name: 'Fruits', icon: '🍎', count: 22 },
  { name: 'Dairy', icon: '🥛', count: 15 },
  { name: 'Eggs', icon: '🥚', count: 8 },
  { name: 'Grains', icon: '🌾', count: 12 },
  { name: 'Honey', icon: '🍯', count: 6 },
  { name: 'Herbs', icon: '🌿', count: 10 },
  { name: 'Meat', icon: '🥩', count: 14 },
];

const CustomerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('browse');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const filteredProducts = mockProducts.filter(product => {
    // Filter by search term
    const matchesSearch = searchTerm === '' || 
                          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          product.farmer.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by category
    // In a real implementation, products would have category associations
    const matchesCategory = selectedCategory === null;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="container-custom">
        {/* Dashboard Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-2">Customer Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user?.name}! Browse fresh produce from local farmers.</p>
        </div>

        {/* Dashboard Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6 overflow-hidden">
          <div className="flex overflow-x-auto">
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'browse' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('browse')}
            >
              Browse Products
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'orders' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('orders')}
            >
              My Orders
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'favorites' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('favorites')}
            >
              Favorites
            </button>
            <button
              className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === 'profile' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-600 hover:text-primary-600'
              }`}
              onClick={() => setActiveTab('profile')}
            >
              My Profile
            </button>
          </div>
        </div>

        {/* Active Tab Content */}
        <div className="animate-fade-in">
          {activeTab === 'browse' && (
            <BrowseProducts 
              products={filteredProducts} 
              categories={categories}
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
            />
          )}
          
          {activeTab === 'orders' && (
            <Orders orders={mockOrders} />
          )}
          
          {activeTab === 'favorites' && (
            <Favorites products={mockProducts.slice(0, 4)} />
          )}
          
          {activeTab === 'profile' && (
            <Profile />
          )}
        </div>
      </div>
    </div>
  );
};

// Browse Products Tab
interface BrowseProductsProps {
  products: Array<{
    id: number;
    name: string;
    price: number;
    farmer: string;
    rating: number;
    image: string;
  }>;
  categories: Array<{
    name: string;
    icon: string;
    count: number;
  }>;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedCategory: string | null;
  setSelectedCategory: (category: string | null) => void;
}

const BrowseProducts: React.FC<BrowseProductsProps> = ({ 
  products, 
  categories,
  searchTerm,
  setSearchTerm,
  selectedCategory,
  setSelectedCategory
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  
  return (
    <div>
      {/* Search and Filter Bar */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="input pl-10"
              placeholder="Search products or farmers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex gap-2">
            <button 
              className="btn-outline flex items-center"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-1" />
              Filters
            </button>
            
            <div className="flex border rounded-md overflow-hidden">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 ${viewMode === 'grid' ? 'bg-primary-100 text-primary-600' : 'bg-white text-gray-500'}`}
              >
                <Grid className="h-5 w-5" />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-2 ${viewMode === 'list' ? 'bg-primary-100 text-primary-600' : 'bg-white text-gray-500'}`}
              >
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-current"></div>
                  <div className="w-5 h-0.5 bg-current"></div>
                  <div className="w-5 h-0.5 bg-current"></div>
                </div>
              </button>
            </div>
          </div>
        </div>
        
        {/* Filters */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price Range</label>
              <select className="input">
                <option>Any Price</option>
                <option>Under $5</option>
                <option>$5 to $10</option>
                <option>$10 to $20</option>
                <option>$20 and above</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Rating</label>
              <select className="input">
                <option>Any Rating</option>
                <option>4 Stars & Up</option>
                <option>3 Stars & Up</option>
                <option>2 Stars & Up</option>
                <option>1 Star & Up</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Sort By</label>
              <select className="input">
                <option>Popularity</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Rating: High to Low</option>
                <option>Newest First</option>
              </select>
            </div>
            
            <div className="flex items-end">
              <button className="btn-primary w-full">Apply Filters</button>
            </div>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Categories Sidebar */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-4 sticky top-4">
            <h3 className="font-bold text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  className={`w-full text-left p-2 rounded-md flex items-center justify-between ${
                    selectedCategory === null ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedCategory(null)}
                >
                  <span className="flex items-center">
                    <span className="text-xl mr-2">🛒</span>
                    <span className="font-medium">All Products</span>
                  </span>
                  <span className="text-sm bg-gray-100 px-2 py-0.5 rounded-full">
                    {products.length}
                  </span>
                </button>
              </li>
              
              {categories.map((category, index) => (
                <li key={index}>
                  <button 
                    className={`w-full text-left p-2 rounded-md flex items-center justify-between ${
                      selectedCategory === category.name ? 'bg-primary-50 text-primary-700' : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedCategory(category.name)}
                  >
                    <span className="flex items-center">
                      <span className="text-xl mr-2">{category.icon}</span>
                      <span className="font-medium">{category.name}</span>
                    </span>
                    <span className="text-sm bg-gray-100 px-2 py-0.5 rounded-full">
                      {category.count}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Products Grid/List */}
        <div className="md:col-span-3">
          {products.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <ShoppingBag className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-bold mb-2">No products found</h3>
              <p className="text-gray-600 mb-4">
                We couldn't find any products matching your search. Try adjusting your filters or search term.
              </p>
              <button 
                className="btn-primary"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory(null);
                }}
              >
                Reset Filters
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <motion.div
                  key={product.id}
                  className="card group"
                  whileHover={{ y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <button className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-sm hover:bg-gray-100">
                      <Heart className="h-5 w-5 text-gray-400 hover:text-red-500" />
                    </button>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                    <p className="text-gray-500 text-sm mb-2">by {product.farmer}</p>
                    <div className="flex items-center mb-3">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm text-gray-600 ml-1">{product.rating} ({Math.floor(Math.random() * 100) + 10} reviews)</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-lg">${product.price.toFixed(2)}</span>
                      <button className="btn-primary text-sm py-1.5 px-3 flex items-center">
                        <ShoppingCart className="h-4 w-4 mr-1" /> Add
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {products.map((product) => (
                <motion.div
                  key={product.id}
                  className="bg-white rounded-lg shadow-sm overflow-hidden"
                  whileHover={{ y: -2 }}
                  transition={{ type: "spring", stiffness: 500 }}
                >
                  <div className="flex flex-col sm:flex-row">
                    <div className="sm:w-48 h-40 overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 p-4 flex flex-col justify-between">
                      <div>
                        <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                        <p className="text-gray-500 text-sm mb-2">by {product.farmer}</p>
                        <div className="flex items-center mb-3">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600 ml-1">{product.rating} ({Math.floor(Math.random() * 100) + 10} reviews)</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-lg">${product.price.toFixed(2)}</span>
                        <div className="flex space-x-2">
                          <button className="btn-outline text-sm py-1.5 px-3">
                            <Heart className="h-4 w-4" />
                          </button>
                          <button className="btn-primary text-sm py-1.5 px-3 flex items-center">
                            <ShoppingCart className="h-4 w-4 mr-1" /> Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Orders Tab
interface OrdersProps {
  orders: Array<{
    id: number;
    date: string;
    items: number;
    total: number;
    status: string;
  }>;
}

const Orders: React.FC<OrdersProps> = ({ orders }) => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">My Orders</h2>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-8">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Items</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#{order.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.items}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${order.total.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-800' :
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-800' :
                      order.status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <Link to={`/orders/${order.id}`} className="text-primary-600 hover:text-primary-800 font-medium">
                      View Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Delivery Tracking for Most Recent Order */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h3 className="text-lg font-bold mb-4">Track Your Latest Order</h3>
        
        <div className="relative">
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          
          <div className="relative flex items-start mb-6">
            <div className="flex-shrink-0 z-10">
              <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 border-2 border-green-500 text-green-500">
                <Check className="h-6 w-6" />
              </div>
            </div>
            <div className="ml-4 pt-3">
              <h4 className="text-md font-medium">Order Placed</h4>
              <p className="text-sm text-gray-500">May 15, 2023 at 10:30 AM</p>
              <p className="text-sm text-gray-600 mt-1">Your order has been received and is being processed</p>
            </div>
          </div>
          
          <div className="relative flex items-start mb-6">
            <div className="flex-shrink-0 z-10">
              <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 border-2 border-green-500 text-green-500">
                <Check className="h-6 w-6" />
              </div>
            </div>
            <div className="ml-4 pt-3">
              <h4 className="text-md font-medium">Order Processed</h4>
              <p className="text-sm text-gray-500">May 15, 2023 at 11:45 AM</p>
              <p className="text-sm text-gray-600 mt-1">Your order has been prepared and packaged</p>
            </div>
          </div>
          
          <div className="relative flex items-start mb-6">
            <div className="flex-shrink-0 z-10">
              <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 border-2 border-green-500 text-green-500">
                <Check className="h-6 w-6" />
              </div>
            </div>
            <div className="ml-4 pt-3">
              <h4 className="text-md font-medium">Shipped</h4>
              <p className="text-sm text-gray-500">May 15, 2023 at 2:15 PM</p>
              <p className="text-sm text-gray-600 mt-1">Your order is on its way to you</p>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex-shrink-0 z-10">
              <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 border-2 border-green-500 text-green-500">
                <Check className="h-6 w-6" />
              </div>
            </div>
            <div className="ml-4 pt-3">
              <h4 className="text-md font-medium">Delivered</h4>
              <p className="text-sm text-gray-500">May 15, 2023 at 4:30 PM</p>
              <p className="text-sm text-gray-600 mt-1">Your order has been delivered. Enjoy!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Favorites Tab
interface FavoritesProps {
  products: Array<{
    id: number;
    name: string;
    price: number;
    farmer: string;
    rating: number;
    image: string;
  }>;
}

const Favorites: React.FC<FavoritesProps> = ({ products }) => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">My Favorite Products</h2>
      
      {products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <motion.div
              key={product.id}
              className="card group"
              whileHover={{ y: -5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <button className="absolute top-2 right-2 p-1.5 bg-white rounded-full shadow-sm hover:bg-gray-100">
                  <Heart className="h-5 w-5 text-red-500 fill-current" />
                </button>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg mb-1">{product.name}</h3>
                <p className="text-gray-500 text-sm mb-2">by {product.farmer}</p>
                <div className="flex items-center mb-3">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="text-sm text-gray-600 ml-1">{product.rating} ({Math.floor(Math.random() * 100) + 10} reviews)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold text-lg">${product.price.toFixed(2)}</span>
                  <button className="btn-primary text-sm py-1.5 px-3 flex items-center">
                    <ShoppingCart className="h-4 w-4 mr-1" /> Add
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <Heart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-bold mb-2">No favorites yet</h3>
          <p className="text-gray-600 mb-4">
            You haven't added any products to your favorites list yet.
          </p>
          <Link to="/customer/dashboard" className="btn-primary">
            Browse Products
          </Link>
        </div>
      )}
    </div>
  );
};

// Profile Tab
const Profile: React.FC = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">My Profile</h2>
      
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
          
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input type="text" className="input" defaultValue="Alice Johnson" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input type="email" className="input" defaultValue="alice@example.com" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
              <input type="tel" className="input" defaultValue="+1 (555) 987-6543" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
              <input type="date" className="input" defaultValue="1990-01-15" />
            </div>
          </div>
          
          <div className="mt-6">
            <button className="btn-primary">Update Information</button>
          </div>
        </div>
        
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Shipping Address</h3>
          
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Street Address</label>
              <input type="text" className="input" defaultValue="123 Main Street" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
              <input type="text" className="input" defaultValue="Anytown" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">State/Province</label>
              <input type="text" className="input" defaultValue="California" />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ZIP/Postal Code</label>
              <input type="text" className="input" defaultValue="12345" />
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
              <select className="input">
                <option>United States</option>
                <option>Canada</option>
                <option>United Kingdom</option>
                <option>Australia</option>
              </select>
            </div>
          </div>
          
          <div className="mt-6">
            <button className="btn-primary">Update Address</button>
          </div>
        </div>
        
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Payment Methods</h3>
          
          <div className="space-y-4">
            <div className="p-4 border border-gray-200 rounded-md relative">
              <div className="absolute top-4 right-4">
                <span className="inline-flex px-2 py-1 text-xs rounded-full font-medium bg-green-100 text-green-800">
                  Default
                </span>
              </div>
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-md mr-4">
                  <div className="w-10 h-6 bg-blue-600 rounded-md relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-6 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="font-medium">Visa ending in 4242</p>
                  <p className="text-sm text-gray-500">Expires 05/2025</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-md">
              <div className="flex items-center">
                <div className="p-2 bg-red-100 rounded-md mr-4">
                  <div className="w-10 h-6 bg-red-600 rounded-md relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-6 h-2 bg-white rounded-full"></div>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="font-medium">Mastercard ending in 5678</p>
                  <p className="text-sm text-gray-500">Expires 09/2024</p>
                </div>
              </div>
            </div>
            
            <button className="btn-outline w-full mt-4">
              <span className="flex items-center justify-center">
                <Plus className="h-4 w-4 mr-1" />
                Add Payment Method
              </span>
            </button>
          </div>
        </div>
        
        <div className="p-6">
          <h3 className="text-lg font-semibold mb-4">Password & Security</h3>
          
          <div className="space-y-6">
            <div>
              <h4 className="font-medium mb-2">Change Password</h4>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                  <input type="password" className="input" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                  <input type="password" className="input" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                  <input type="password" className="input" />
                </div>
              </div>
              
              <div className="mt-4">
                <button className="btn-primary">Update Password</button>
              </div>
            </div>
            
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
              <p className="text-sm text-gray-600 mb-4">Enable two-factor authentication for an extra layer of security.</p>
              <button className="btn-outline">Enable 2FA</button>
            </div>
            
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-medium mb-2">Delete Account</h4>
              <p className="text-sm text-gray-600 mb-4">Once you delete your account, there is no going back. Please be certain.</p>
              <button className="btn bg-red-600 text-white hover:bg-red-700 focus:ring-red-500">Delete Account</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface CheckProps {
  className?: string;
}

const Check: React.FC<CheckProps> = ({ className }) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );
};

export default CustomerDashboard;